import UIKit

let numbers = [1, 3, 6, 7, 7, 12, 14]

//brute force
/* func bruteForceTwoSum(array: [Int], sum: Int) -> Bool {
    
    for i in 0..<array.count {
        for j in 0..<array.count where j != i {
            if array[j] + array[i] == sum {
                print("True")
                return true
            } else{
                print("False")
            }
            
        }
    }
    
    return false
}

bruteForceTwoSum(array: numbers, sum: 9) */

//binary search
func twoSumBinarySearch(array: [Int], sum: Int) -> Bool {
    for i in 0..<array.count{
        let compliment = sum - array[i]
        
        var tempArray = array
        tempArray.remove(at: i)
        
        let hasCompliment = binarySearch(array: tempArray, key: compliment)
        print("num: \(array[i]) - \(hasCompliment)")
        
        if hasCompliment == true {
            print("true - num: \(array[i]), compliment: \(compliment)")
            return true
        }
    }
    return false
}
twoSumBinarySearch(array: numbers, sum: 9)
