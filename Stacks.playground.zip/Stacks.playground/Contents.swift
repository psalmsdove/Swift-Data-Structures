import UIKit

class Node {
    let value: Int
    var next: Node?
    init(value: Int) {
        self.value = value
    }
}


class Stack {
    var top: Node?
    //Pushing an item to the list
    func push(_ value: Int) {
        let oldTop = top
        top = Node(value: value)
        top?.next = oldTop
    }
    //Popping an item from list
    func pop() -> Int? {
        var currentTop = top
        top = top?.next
        return currentTop?.value
        
    }
    //Seeing the top item
    func peek() -> Int?{
        return top?.value
    }
}

let stack = Stack()
stack.push(1)
stack.push(2)
stack.push(3)

stack.peek()

let firstPop = stack.pop()
let secondPop = stack.pop()
