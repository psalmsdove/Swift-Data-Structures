import UIKit

var sampleSentence = "This is a sentence to try reversing words"

func reverseWordsInSentence(sentence: String) -> String{
    let allWords = sampleSentence.components(separatedBy: " ")
    var newSentence = ""
    for word in allWords {
        if newSentence != ""{
            newSentence += " "
        }
       let reverseWord = String(word.reversed())
        newSentence += reverseWord
    }
    return newSentence
}

print(reverseWordsInSentence(sentence: sampleSentence))
 
