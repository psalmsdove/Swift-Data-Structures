import UIKit

let unsortedArray = [35, 40, 50, 20, 80, 90, 45, 10]

func merge(leftArr:[Int], rightArr:[Int]) -> [Int] {
    var sortedArr: [Int] = []
    var left = leftArr
    var right = rightArr
    while left.count > 0 && right.count > 0 {
        if left.first! < right.first! {
            sortedArr.append(left.removeFirst())
        } else {
            sortedArr.append(right.removeFirst())
        }
    }
    return sortedArr + left + right
}

func mergeSort(array: [Int]) -> [Int] {
    guard array.count > 1 else {
        return array
    }
    let leftArr = Array(array[0..<array.count/2])
    let rightArr = Array(array[array.count/2..<array.count])
    
    return merge(leftArr: mergeSort(array: leftArr), rightArr: mergeSort(array: rightArr))
}

print(mergeSort(array: unsortedArray))
