import UIKit

func uniqueLetters(inputStr: String) -> Bool {
    var checkedLetters = [Character]()
    for item in inputStr {
        if checkedLetters.contains(item){
            return false
        }
        checkedLetters.append(item)
    }
    return true
}

uniqueLetters(inputStr: "Duplicatestring")
