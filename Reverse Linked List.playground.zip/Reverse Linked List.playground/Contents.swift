import UIKit

// input: 1-2-3-4-5
// output: 5-4-3-2-1

final class LinkedNode{
    var val: Int
    var next: LinkedNode?
    
    init(val: Int){
        self.val = val
    }
}



final class ReverseLinkedList{
    static func reverse(_ node: LinkedNode?) -> LinkedNode? {
        guard let node = node else {return nil}
        var nextNode = node.next
        var currentNode = LinkedNode(val: node.val)
    
        while nextNode != nil {
            
            let newNode = LinkedNode(val: nextNode!.val)
            newNode.next = currentNode
            
            currentNode = newNode
            
            nextNode = nextNode?.next
        }
        return currentNode
    }
}

var linkedNode = LinkedNode(val: 1)
linkedNode.next = LinkedNode(val: 2)
linkedNode.next?.next = LinkedNode(val: 3)
linkedNode.next?.next?.next = LinkedNode(val: 4)
linkedNode.next?.next?.next?.next = LinkedNode(val: 5)

let answer = ReverseLinkedList.reverse(linkedNode)
print("rootNode \(answer?.val)")
print("node1 \(answer?.next?.val)")
print("node2 \(answer?.next?.next?.val)")
print("node3 \(answer?.next?.next?.next?.val)")
print("node4 \(answer?.next?.next?.next?.next?.val)")
print("node5 \(answer?.next?.next?.next?.next?.next?.val)")
