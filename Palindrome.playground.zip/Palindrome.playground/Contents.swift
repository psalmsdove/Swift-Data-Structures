import UIKit

func isPalindrome(inputString: String) -> Bool{
    return inputString.reversed() == Array(inputString)
}
isPalindrome(inputString: "dad")
isPalindrome(inputString: "apple")
