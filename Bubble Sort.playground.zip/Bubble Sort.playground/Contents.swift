import UIKit

func bubbleSort (arr: [Int]) -> [Int] {
    var array = arr
    for _ in 0..<array.count - 1 {
        for j in 0..<array.count - 1 {
            if (array[j] > array[j+1]){
                let temp = array[j]
                array[j] = array[j+1]
                array[j+1] = temp
            }
        }
    }
    return array
}

let unsortedArray = [3, 7, 5, 1, 41, 12, 8, 32, 2, 65]
bubbleSort(arr: unsortedArray)

