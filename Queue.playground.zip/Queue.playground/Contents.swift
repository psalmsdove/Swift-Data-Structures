import UIKit



struct Queue<T> {
    //Creating the queue
    var array = [T]()
    //Enqueue
    public mutating func enqueue(_ element: T){
        array.append(element)
    }
    //Dequeue
    public mutating func dequeue() -> T?{
        if isEmpty{
            return nil
        }
        return array.removeFirst()
    }
    //Finding first element
    public var front: T?{
        return array.first
    }
    //Is empty control
    public var isEmpty: Bool{
        return array.isEmpty
    }
    //Element number
    public var count: Int {
        return array.count
    }
}
var q = Queue<String>()
q.enqueue("Ada")
q.enqueue("Burak")
q.enqueue("Deniz")

print(q.array)
print(q.front)
print(q.count)
print(q.dequeue())
print(q.array)
